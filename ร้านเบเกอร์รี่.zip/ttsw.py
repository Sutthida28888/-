from tkinter import*
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter import messagebox
from tkinter import Toplevel
from datetime import datetime
from tkinter import filedialog
from io import BytesIO #เป็นส่วนหนึ่งของการทำงานกับข้อมูลไบนารีเช่นการอ่าน/เขียนไฟล์แบบไบนารี หรือการประมวลผลข้อมูลไบนารีในหน่วยความจำ
import sqlite3
conn = sqlite3.connect("sweet.db")
c = conn.cursor()

#หน้าหลัก
root=tk.Tk()
root.title('โหวเธอ หวานเจี๊ยบ เบเกอรี่')
root.geometry('1000x650+10+10')
root.resizable(FALSE,FALSE)
img1 = ImageTk.PhotoImage(Image.open("open.png"))
Label(image=img1,width=550, height=650,bg='white').place(x=0,y=0)

# แถบแรกผู้พัฒนา
def show_developer_info():
    developer_info_window = Toplevel(root)
    developer_info_window.title("ข้อมูลผู้พัฒนา")
    developer_info_window.geometry('500x500+10+10')
    developer_info_window.resizable(FALSE,FALSE)
    developer_info_window.configure(background='light sky blue')

    # โหลดรูปภาพและแปลงเป็น ImageTk.PhotoImage
    img_path = "member.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(developer_info_window, image=img, bg='white').pack()
    developer_info_window.image = img  # เก็บอ้างอิงไว้เพื่อไม่ให้รูปถูกทำลายเมื่อฟังก์ชันจบ

file_menu = Menu(root)
menubar = Menu(root)
root.config(menu=menubar)

file_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="ผู้พัฒนา", menu=file_menu, command=show_developer_info)
file_menu.add_command(label="แสดงข้อมูลผู้พัฒนา", command=show_developer_info)

# แถบผู้ดูแล-1.หน้าข้อมูลลูกค้าทั้งหมด
def show_all_users():
    all_users_window = Toplevel(root)
    all_users_window.title("ข้อมูลลูกค้าทั้งหมด")
    all_users_window.geometry('600x400+10+10')
    all_users_window.resizable(FALSE, FALSE)
    all_users_window.configure(background='light sky blue')
    img_path = "111.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(all_users_window, image=img, bg='light sky blue').pack()
    all_users_window.image = img

    def fetch_data_and_display():
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("SELECT * FROM ผู้ใช้")
        users = c.fetchall()
        conn.close()

        user_listbox.delete(0, END)

        for user in users:
            user_listbox.insert(END, f"  ID : {user[0]}  ชื่อ : {user[1]}  เบอร์โทร : {user[2]}  จำนวนการเข้าใช้บริการ : {user[3]}")

    # สร้างปุ่ม "ดึงข้อมูลจากตารางผู้" และกำหนดคำสั่งให้เรียกฟังก์ชัน fetch_data_and_display
    Button(all_users_window, text="ดูข้อมูลลูกค้าทั้งหมด", command=fetch_data_and_display,font='arial 10 bold').place(x=240, y=350)

    # สร้าง Listbox และกำหนดความกว้างและความสูง
    user_listbox = Listbox(all_users_window, width=60, height=17, bg='AliceBlue',font='arial 10 bold')
    user_listbox.place(x=90,y=50)

    def home():
        all_users_window.withdraw()
        root.deiconify()
    ok_button = tk.Button(all_users_window, text="🛖", command=home, bg='white')
    ok_button.place(x=570,y=370)

# แถบผู้ดูแล-2.หน้าแก้ไขข้อมูลลูกค้า
def edit_customer_info():
    root.iconify()
    edit_window = Toplevel(root)
    edit_window.title("แก้ไขข้อมูลลูกค้า")
    edit_window.geometry('600x400+10+10')
    edit_window.resizable(FALSE,FALSE)
    edit_window.configure(background='light yellow')
    img_path = "222.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(edit_window, image=img, bg='light sky blue').pack()
    edit_window.image = img

    name1_entry = Entry(edit_window, bd=5, width=20, bg='white', font=('arial 10 bold'))
    name1_entry.place(x=230,y=145)
    name_entry = Entry(edit_window, bd=5, width=20, bg='white', font=('arial 10 bold'))
    name_entry.place(x=275,y=255)
    phone2_entry = Entry(edit_window, bd=5, width=20, bg='white', font=('arial 10 bold'))
    phone2_entry.place(x=275,y=290)

    def load_customer_data():
        selected_name = name1_entry.get()
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("SELECT * FROM ผู้ใช้ WHERE ชื่อ=?", (selected_name,))
        customer_data = c.fetchone()
        conn.close()

        if customer_data:
            # แสดงข้อมูลลูกค้าในช่องกรอกข้อมูลต่าง ๆ
            name_entry.delete(0, END)
            name_entry.insert(0, customer_data[1])  # ตำแหน่งข้อมูลชื่อลูกค้าในตาราง
            phone2_entry.delete(0, END)
            phone2_entry.insert(0, customer_data[2])  # ตำแหน่งข้อมูลเบอร์โทรลูกค้าในตาราง
            # คุณจะต้องแทนตำแหน่งของข้อมูลใน customer_data ด้วยตำแหน่งที่ถูกต้องในตารางของคุณ
        else:
            messagebox.showerror("Error", "ไม่พบข้อมูลลูกค้า")

    load_button = Button(edit_window, text="🔍ค้นหา", font=('arial 10 bold'), bg='white', command=load_customer_data)
    load_button.place(x=400,y=145)

    def save_customer_data():
        new_name = name_entry.get()
        new_phone = phone2_entry.get()
        selected_name = name1_entry.get()
        # เพิ่มการรับข้อมูลจากช่องกรอกข้อมูลอื่น ๆ ตามความต้องการ
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("UPDATE ผู้ใช้ SET ชื่อ=?, เบอร์โทร=? WHERE ชื่อ=?", (new_name, new_phone, selected_name))
        # เพิ่มคำสั่งอัปเดตข้อมูลในตารางตามความต้องการ
        conn.commit()
        conn.close()

    def save_order_data():
        new_name = name_entry.get()
        selected_name = name1_entry.get()
        # เพิ่มการรับข้อมูลจากช่องกรอกข้อมูลอื่น ๆ ตามความต้องการ
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("UPDATE คำสั่งซื้อ SET ชื่อ=? WHERE ชื่อ=?", (new_name, selected_name))
        # เพิ่มคำสั่งอัปเดตข้อมูลในตารางตามความต้องการ
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "แก้ไขข้อมูลเสร็จสิ้น")
        edit_window.destroy()

    # ปุ่มบันทึกข้อมูล
    save_button = Button(edit_window, text="บันทึก", font=('arial 10 bold'), bg='white', command=lambda: [save_customer_data(), save_order_data()])
    save_button.place(x=230, y=350)  # เปลี่ยนตำแหน่งตามความต้องการ

    def Reset():
        name_entry.delete(0,END)
        name1_entry.delete(0,END)
        phone2_entry.delete(0,END)
    Reset_button = Button(edit_window,text='ยกเลิก',font=('arial 10 bold'), bg='white', command=Reset)
    Reset_button.place(x=320,y=350)

    def home():
        edit_window.withdraw()
        root.deiconify()
    ok_button = tk.Button(edit_window, text="🛖", command=home, bg='white')
    ok_button.place(x=570,y=370)

# แถบผู้ดูแล-3.หน้าแก้ไขคำสั่งข้อมูลลูกค้า
def edit_order_info():
    root.iconify()
    edit_order = Toplevel(root)
    edit_order.title("แก้ไขคำสั่งซื้อลูกค้า")
    edit_order.geometry('600x400+10+10')
    edit_order.resizable(FALSE,FALSE)
    edit_order.configure(background='light yellow')
    img_path = "333.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(edit_order, image=img, bg='light sky blue').pack()
    edit_order.image = img

    selected_product = StringVar()
    selected_price = StringVar()

    # สร้างช่อง Entry สำหรับใส่ชื่อ
    entry1 = Entry(edit_order, bd=5, width=30, font=('arial 10'))
    entry1.place(x=110, y=65)
    entry2 = Entry(edit_order, bd=0, width=0, font=('arial 10')) #รายการ
    entry2.place(x=100, y=310)
    entry3 = Entry(edit_order, bd=5, width=8, font=('arial 10'), textvariable=selected_price) #ราคา
    entry3.place(x=230, y=345)
    entry4 = Entry(edit_order, bd=5, width=8, font=('arial 10')) #จำนวน
    entry4.place(x=100, y=345)
    entry5 = Entry(edit_order, bd=5, width=10, font=('arial 10')) #id ลบ
    entry5.place(x=440, y=270)
    id_entry = Entry(edit_order, bd=5, width=10, font=('arial 10')) #id แก้ไข
    id_entry.place(x=100, y=270)

    # ปุ่มยืนยันเพื่อค้นหาข้อมูลคำสั่งซื้อ
    def search_orders():
        name_to_search = entry1.get()
        if name_to_search:
            # ค้นหาข้อมูลคำสั่งซื้อในฐานข้อมูลด้วยชื่อ
            conn = sqlite3.connect("ttsw.db")
            c = conn.cursor()
            c.execute("SELECT * FROM คำสั่งซื้อ WHERE ชื่อ=?", (name_to_search,))
            orders = c.fetchall()
            conn.close()
 
            # ล้าง Listbox และ Entry เดิม (หากมี)
            order_listbox.delete(0, END)

            # แสดงข้อมูลคำสั่งซื้อที่ค้นพบใน Listbox
            for order in orders:
                order_id = order[0]
                order_name = order[3]
                order_date = order[1]
                order_time = order[2]
                order_quantity = order[4]
                order_items = order[5]
                order_price = order[6]
                order_listbox.insert(END, f"ID: {order_id}  ชื่อ: {order_name}  วันที่: {order_date}  เวลา: {order_time}  จำนวน: {order_quantity}  รายการ: {order_items}  ราคา: {order_price}")

    search_button = Button(edit_order, text="🔍ค้นหา", font=('arial 10 bold'), bg='white', command=search_orders)
    search_button.place(x=350, y=63)

    # Listbox สำหรับแสดงรายการคำสั่งซื้อที่ค้นพบ
    order_listbox = Listbox(edit_order, width=70, height=4, font=('arial 10 bold'))
    order_listbox.place(x=50, y=100)

    def reset():
        entry1.delete(0,END)
        order_listbox.delete(0,END)
    Reset_button = Button(edit_order,text='ยกเลิก',font=('arial 10 bold'), bg='white', command=reset)
    Reset_button.place(x=420,y=63)

    def delete():
        id = entry5.get()
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("DELETE FROM คำสั่งซื้อ WHERE id=?", (id,))
        conn.commit()
        conn.close()
        messagebox.showinfo('success','ลบเรียบร้อย')
    delete_button = Button(edit_order, text="ยืนยันลบ", font=('arial 10 bold'), bg='white', command=delete)
    delete_button.place(x=450, y=305)

    # สร้าง Combobox หรือ OptionMenu แก้ไขคำสั่งซื้อ
    product_options = ttk.Combobox(edit_order, width=20, textvariable=selected_product, state="readonly")
    product_options.place(x=100, y=305)
    product_options.bind("<<ComboboxSelected>>")
    
    def search_orders():
        id_to_search = id_entry.get()
        if id_to_search:
            conn = sqlite3.connect("ttsw.db")
            c = conn.cursor()
            c.execute("SELECT * FROM คำสั่งซื้อ WHERE id=?", (id_to_search,))
            order = c.fetchone()

            if order:
                # แสดงข้อมูลรายการและราคาใน Entry2 และ Entry1
                entry3.delete(0, END)
                entry3.insert(0, order[6])  # ราคา
                entry2.delete(0, END)
                entry2.insert(0, order[5])  # รายการ
                entry4.delete(0, END)
                entry4.insert(0, order[4])  # จำนวน

                # ค้นหาชื่อสินค้าจากตารางขนมและเครื่องดื่ม
                c.execute("SELECT ชื่อสินค้า FROM ขนม")
                products = c.fetchall()
                product_names = [product[0] for product in products]

                c.execute("SELECT ชื่อสินค้า FROM เครื่องดืม")
                drinks = c.fetchall()
                drink_names = [drink[0] for drink in drinks]

                # ปิดการเชื่อมต่อกับฐานข้อมูลที่นี่
                # conn.close()

                # ลบรายการที่มีอยู่ใน Combobox หรือ OptionMenu ทั้งหมด
                product_options["values"] = []

                # กำหนดรายการใหม่ใน Combobox หรือ OptionMenu
                product_options["values"] = product_names + drink_names

                # ตั้งค่าค่าเริ่มต้นให้เป็นชื่อสินค้าที่ถูกเลือก
                selected_product.set(order[5])  # รายการ

                def select_product(event):
                    selected_product_name = selected_product.get()
            
                    # ค้นหาราคาของสินค้าที่ถูกเลือกจากฐานข้อมูล
                    conn = sqlite3.connect("ttsw.db")
                    c = conn.cursor()
                    c.execute("SELECT ราคา FROM ขนม WHERE ชื่อสินค้า=?", (selected_product_name,))
                    price_product = c.fetchone()

                    if not price_product:
                        c.execute("SELECT ราคา FROM เครื่องดืม WHERE ชื่อสินค้า=?", (selected_product_name,))
                        price_drink = c.fetchone()

                    if price_product:
                        selected_price.set(price_product[0])
                    elif price_drink:
                        selected_price.set(price_drink[0])
                    else:
                        # หากไม่พบราคาให้ตั้งเป็น 0
                        selected_price.set(0)

                product_options.bind("<<ComboboxSelected>>", select_product)

                def calculate_total_price(event):
                    try:
                        # ดึงค่าจำนวนจาก entry4
                        quantity = int(entry4.get())

                        # ดึงราคาปัจจุบันจาก entry3
                        current_price = float(selected_price.get())

                        # คำนวณราคารวม
                        total_price = quantity * current_price

                        # แสดงผลลัพธ์ใน entry3
                        entry3.delete(0, END)
                        entry3.insert(0, total_price)
                    except ValueError:
                        # กรณีผู้ใช้ป้อนข้อมูลไม่ถูกต้อง
                        entry3.delete(0, END)
                        entry3.insert(0, 0.0)

                # เชื่อมต่อฟังก์ชัน calculate_total_price กับเหตุการณ์ "<KeyRelease>" ของ entry4
                entry4.bind("<KeyRelease>", calculate_total_price)

            else:
                messagebox.showerror("Error", "ไม่พบคำสั่งซื้อที่มี ID ที่ระบุ")

    search_button = Button(edit_order, text="ยืนยัน", font=('arial 10 bold'), bg='white', command=search_orders)
    search_button.place(x=200, y=268)

    def save_selected_order():
        # ดึงข้อมูลที่ผู้ใช้แก้ไขจาก entry2 และ entry3
        updated_item = selected_product.get()
        updated_price = entry3.get()
        updated_quantity = entry4.get()
        id_to_search = id_entry.get()
        # เพิ่มการรับข้อมูลจากช่องกรอกข้อมูลอื่น ๆ ตามความต้องการ
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("UPDATE คำสั่งซื้อ SET จำนวน=?, รายการ=?, ราคา=? WHERE id=?", (updated_quantity, updated_item, updated_price, id_to_search))
        # เพิ่มคำสั่งอัปเดตข้อมูลในตารางตามความต้องการ
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "แก้ไขข้อมูลเสร็จสิ้น")
        edit_order.destroy()

    # ปุ่มบันทึกข้อมูล
    save_button = Button(edit_order, text="บันทึกแก้ไข", font=('arial 10 bold'), bg='white', command=lambda: [save_selected_order(), search_orders()])
    save_button.place(x=260, y=305)  # เปลี่ยนตำแหน่งตามความต้องการ

    def Reset():
        entry2.delete(0,END)
        entry3.delete(0,END)
        entry4.delete(0,END)
        id_entry.delete(0,END)
    Reset_button = Button(edit_order,text='ยกเลิก',font=('arial 10 bold'), bg='white', command=Reset)
    Reset_button.place(x=450,y=360)

    def home():
        edit_order.withdraw()
        root.deiconify()
    ok_button = tk.Button(edit_order, text="🛖", command=home, bg='white')
    ok_button.place(x=570,y=370)

# แถบผู้ดูแล-4.หน้าการจัดการรายการสินค้า
def product_info():
    root.iconify()
    edit_product = Toplevel(root)
    edit_product.title("การจัดการรายการสินค้า")
    edit_product.geometry('600x400+10+10')
    edit_product.resizable(FALSE,FALSE)
    edit_product.configure(background='light yellow')
    img_path = "444.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(edit_product, image=img, bg='light sky blue').pack()
    edit_product.image = img

    #เฟรม1-แสดงการเพิ่มขนม
    edit_product1=Frame(edit_product,bg='white',highlightbackground='white',highlightthickness=0,width=100,height=200)
    edit_product1.place(x=85,y=110)

    # สร้างตัวแปรเก็บข้อมูลสินค้า
    product_name = StringVar()
    product_price = StringVar()
    product_image_path = StringVar()

    def browse_image():
        file_path = filedialog.askopenfilename()
        product_image_path.set(file_path)

    def save_product():
        name = product_name.get()
        price = product_price.get()
        image_product = product_image_path.get()

        if name and price and image_product:
            try:
                conn = sqlite3.connect("ttsw.db")
                cursor = conn.cursor()

                # เพิ่มข้อมูลลงในตารางขนม
                cursor.execute("INSERT INTO ขนม (ชื่อสินค้า, ราคา) VALUES (?, ?)", (name, price))
                conn.commit()

                # ดึงรหัสสินค้าที่เพิ่มล่าสุด
                cursor.execute("SELECT last_insert_rowid()")
                product_id = cursor.fetchone()[0]

                # เพิ่มข้อมูลรูปภาพลงในตารางรูปภาพขนม
                with open(image_product, "rb") as image_file:
                    image_data = image_file.read()
                cursor.execute("INSERT INTO รูปภาพขนม (id, รูปภาพ) VALUES (?, ?)", (product_id, image_data))
                conn.commit()

                conn.close()
                messagebox.showinfo("บันทึกสำเร็จ", "บันทึกข้อมูลสินค้าเรียบร้อยแล้ว")
                edit_product.destroy()
                root.deiconify()
            except Exception as e:
                messagebox.showerror("ข้อผิดพลาด", f"เกิดข้อผิดพลาด: {str(e)}")
        else:
            messagebox.showerror("ข้อมูลไม่ครบ", "กรุณากรอกข้อมูลให้ครบถ้วน")

    label_name = Label(edit_product1, text="ชื่อสินค้า:", font=('arial 10 bold'), bg='white')
    label_name.pack()
    entry_name = Entry(edit_product1, textvariable=product_name, font=('arial 10 bold'), bg='white')
    entry_name.pack()

    label_price = Label(edit_product1, text="ราคา:", font=('arial 10 bold'), bg='white')
    label_price.pack()
    entry_price = Entry(edit_product1, textvariable=product_price, font=('arial 10 bold'), bg='white')
    entry_price.pack()

    button_browse = Button(edit_product1, text="เลือกไฟล์", command=browse_image, font=('arial 10 bold'), bg='white')
    button_browse.pack()

    label_selected_file = Label(edit_product1, textvariable=product_image_path, font=('arial 10 bold'), bg='white')
    label_selected_file.pack()

    button_save = Button(edit_product1, text="บันทึก", font=('arial 10 bold'), bg='white', command=save_product)
    button_save.pack()

    #เฟรม1.1-แสดงการลบขนม
    del_product1=Frame(edit_product,bg='white',highlightbackground='white',highlightthickness=0,width=150,height=50)
    del_product1.place(x=85,y=300)
    label_product = Label(del_product1, text="ลบสินค้า:", font=('arial 10 bold'), bg='white')
    label_product.place(x=0,y=0)
    del_product = Entry(del_product1, bd=2, width=10, font=('arial 10'))
    del_product.place(x=0, y=20)

    def delete_product():
        id = del_product.get()
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        # ลบข้อมูลในตาราง ขนม
        c.execute("DELETE FROM ขนม WHERE id=?", (id,))
        
        # ลบข้อมูลในตาราง รูปภาพ
        c.execute("DELETE FROM รูปภาพขนม WHERE id=?", (id,))
        conn.commit()
        conn.close()
        messagebox.showinfo('success','ลบเรียบร้อย')

    delete_button = Button(del_product1, text="ยืนยันลบ", font=('arial 10 bold'), bg='white', command=delete_product)
    delete_button.place(x=80, y=20)

    #เฟรม2-แสดงการเพิ่มเครื่องดืม
    edit_product2=Frame(edit_product,bg='white',highlightbackground='white',highlightthickness=0,width=100,height=200)
    edit_product2.place(x=365,y=110)

    # สร้างตัวแปรเก็บข้อมูลสินค้า
    drink_name = StringVar()
    drink_price = StringVar()
    drink_image_path = StringVar()

    def browse_drink_image():
        file_path = filedialog.askopenfilename()
        drink_image_path.set(file_path)

    def save_drink():
        name = drink_name.get()
        price = drink_price.get()
        image_drink = drink_image_path.get()

        if name and price and image_drink:
            try:
                conn = sqlite3.connect("ttsw.db")
                cursor = conn.cursor()

                # เพิ่มข้อมูลลงในตารางขนม
                cursor.execute("INSERT INTO เครื่องดืม (ชื่อสินค้า, ราคา) VALUES (?, ?)", (name, price))
                conn.commit()

                # ดึงรหัสสินค้าที่เพิ่มล่าสุด
                cursor.execute("SELECT last_insert_rowid()")
                drink_id = cursor.fetchone()[0]

                # เพิ่มข้อมูลรูปภาพลงในตารางรูปภาพขนม
                with open(image_drink, "rb") as image_file:
                    image_data = image_file.read()
                    edit_product.destroy()
                    root.deiconify()
                cursor.execute("INSERT INTO รูปภาพเครื่องดืม (id, รูปภาพ) VALUES (?, ?)", (drink_id, image_data))
                conn.commit()

                conn.close()
                messagebox.showinfo("บันทึกสำเร็จ", "บันทึกข้อมูลสินค้าเรียบร้อยแล้ว")
                edit_product.destroy()
            except Exception as e:
                messagebox.showerror("ข้อผิดพลาด", f"เกิดข้อผิดพลาด: {str(e)}")
        else:
            messagebox.showerror("ข้อมูลไม่ครบ", "กรุณากรอกข้อมูลให้ครบถ้วน")

    label_name = Label(edit_product2, text="ชื่อสินค้า:", font=('arial 10 bold'), bg='white')
    label_name.pack()
    entry_name = Entry(edit_product2, textvariable=drink_name, font=('arial 10 bold'), bg='white')
    entry_name.pack()

    label_price = Label(edit_product2, text="ราคา:", font=('arial 10 bold'), bg='white')
    label_price.pack()
    entry_price = Entry(edit_product2, textvariable=drink_price, font=('arial 10 bold'), bg='white')
    entry_price.pack()

    button_browse = Button(edit_product2, text="เลือกไฟล์", command=browse_drink_image, font=('arial 10 bold'), bg='white')
    button_browse.pack()

    label_selected_file = Label(edit_product2, textvariable=drink_image_path, font=('arial 10 bold'), bg='white')
    label_selected_file.pack()

    button_save = Button(edit_product2, text="บันทึก", font=('arial 10 bold'), bg='white', command=save_drink)
    button_save.pack()

    #เฟรม2.1-แสดงการลบเครื่องดืม
    del_product2=Frame(edit_product,bg='white',highlightbackground='white',highlightthickness=0,width=150,height=50)
    del_product2.place(x=375,y=300)
    label_product = Label(del_product2, text="บรรทัดที่จะลบ:", font=('arial 10 bold'), bg='white')
    label_product.place(x=0,y=0)
    del_drink = Entry(del_product2, bd=2, width=10, font=('arial 10'))
    del_drink.place(x=0, y=20)

    def delete_drink():
        id = del_drink.get()
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        # ลบข้อมูลในตาราง เครื่องดืม
        c.execute("DELETE FROM เครื่องดืม WHERE id=?", (id,))
        
        # ลบข้อมูลในตาราง รูปภาพ
        c.execute("DELETE FROM รูปภาพเครื่องดืม WHERE id=?", (id,))
        conn.commit()
        conn.close()
        messagebox.showinfo('success','ลบเรียบร้อย')

    del_button = Button(del_product2, text="ยืนยันลบ", font=('arial 10 bold'), bg='white', command=delete_drink)
    del_button.place(x=80, y=20)

    def home():
        edit_product.withdraw()
        root.deiconify()
    ok_button = tk.Button(edit_product, text="🛖", command=home, bg='white')
    ok_button.place(x=570,y=370)
    
file_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="ผู้ดูแล", menu=file_menu)
edit_menu = Menu(file_menu)
file_menu.add_cascade(label="ข้อมูลลูกค้า",command=show_all_users)
file_menu.add_cascade(label="การแก้ไขข้อมูลลูกค้า",command=edit_customer_info)
file_menu.add_cascade(label="การแก้ไขคำสั่งซื้อ",command=edit_order_info)
file_menu.add_cascade(label="การจัดการรายการสินค้า",command=product_info)

# แถบออกจากระบบ
def exit_system():
    confirm = messagebox.askyesno("ออกจากระบบ", "คุณต้องการที่จะออกจากระบบหรือไม่?")
    if confirm:
        root.quit()

file_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="ออกจากระบบ", menu=file_menu)
file_menu.add_command(label="ออกจากระบบ", command=exit_system)

#หน้าหลัก-ที่แบ่งเฟรมสำหรับลงทะเบียนและล็อคอิน
f1=Frame(bg='white',highlightbackground='white',highlightthickness=0,width=450,height=650)
f1.place(x=550,y=0)
Label(f1,text='ยินดีต้อนรับคุณลูกค้า',fg='black',font='JasmineUPC 25 bold',bg='white').place(x=100,y=100)
Label(f1,text='กรุณากรอกเบอร์โทร',fg='black',font='JasmineUPC 15',bg='white').place(x=40,y=170)
Label(f1,text='ลงทะเบียนลูกค้าใหม่',fg='black',font='JasmineUPC 25 bold',bg='white').place(x=100,y=300)
Label(f1,text='ชื่อ',fg='black',font='JasmineUPC 15',bg='white').place(x=50,y=370)
Label(f1,text='เบอร์โทร',fg='black',font='JasmineUPC 15',bg='white').place(x=50,y=420)
login=StringVar()
ชื่อ=StringVar()
เบอร์โทร=StringVar()
entry_login=Entry(f1,textvariable=login,bd=4,width=30,bg='white',highlightbackground='grey',highlightthickness=1)
entry_login.place(x=200,y=170)
entry_ชื่อ=Entry(f1,textvariable=ชื่อ,bd=4,width=40,bg='white',highlightbackground='grey',highlightthickness=1)
entry_ชื่อ.place(x=130,y=370)
entry_เบอร์โทร=Entry(f1,textvariable=เบอร์โทร,bd=4,width=40,bg='white',highlightbackground='grey',highlightthickness=1)
entry_เบอร์โทร.place(x=130,y=420)

#กระบวนการล็อคอินเพื่อแสดงหน้าถัดไป
access_count = '0'
def login_action():
    global access_count
    phone_login = entry_login.get()
    try:
        int(phone_login)
        # เชื่อมต่อกับฐานข้อมูล
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        # Check if the phone number exists in the database
        c.execute("SELECT * FROM ผู้ใช้ WHERE เบอร์โทร=?", (phone_login,))
        result = c.fetchone()
        if result:
            # เพิ่มจำนวนการเข้าใช้งานของผู้ใช้ที่เข้าสู่ระบบ
            c.execute("UPDATE ผู้ใช้ SET จำนวนเข้าใช้บริการ = จำนวนเข้าใช้บริการ + 1 WHERE เบอร์โทร=?", (phone_login,))
            conn.commit()
            # ตรวจสอบจำนวนการเข้าใช้งาน
            c.execute("SELECT จำนวนเข้าใช้บริการ FROM ผู้ใช้ WHERE เบอร์โทร=?", (phone_login,))
            access_count = c.fetchone()[0]
            if access_count == '10':
                c.execute("UPDATE ผู้ใช้ SET จำนวนเข้าใช้บริการ = 0 WHERE เบอร์โทร=?", (phone_login,))
                conn.commit()
            elif access_count == '1':
                messagebox.showinfo("Success", "ขอแสดงความยินดี\nคุณได้รับเมนูพิเศษ บิงซูผลไม้ฟรี ฟรี!")
            show_menu()
        else:
            # If the phone number does not exist, show a message box
            messagebox.showerror("Error", "ไม่พบข้อมูลของคุณ กรุณาลงทะเบียน")
    except ValueError:
        messagebox.showerror("Error", "ไม่พบข้อมูล")
        return
    finally:
        conn.close()
Button(f1,bd=5,fg='black',bg='light blue',width=10,text='ยืนยัน',command=login_action).place(x=100,y=220)

def Reset():
    entry_login.delete(0,END)
Button(f1,bd=5,fg='black',bg='light blue',width=10,text='ยกเลิก',command=Reset).place(x=260,y=220)

#กระบวนการลงทะเบียนลูกค้าใหม่
def add():
    global access_count
    name = entry_ชื่อ.get()
    phone_number = entry_เบอร์โทร.get()
    user_used = access_count
    try:
        int(phone_number)
    except ValueError:
        messagebox.showerror("Error", "กรุณาใส่เบอร์โทรที่ถูกต้อง")
        return
    
    try:
        # เชื่อมต่อกับฐานข้อมูล
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()

        # Insert a new customer into the database
        c.execute("INSERT INTO ผู้ใช้ (ชื่อ, เบอร์โทร, จำนวนเข้าใช้บริการ) VALUES (?, ?, ?)", (name, phone_number, user_used))
        conn.commit()

        # Show a success message
        messagebox.showinfo("Success", "เพิ่มข้อมูลลูกค้าเรียบร้อยแล้ว")

        # Clear the entry fields
        reset()
    except sqlite3.Error as e:
        messagebox.showerror("Error", f"เกิดข้อผิดพลาดในการเพิ่มข้อมูล: {str(e)}")
    finally:
        conn.close()  # ปิดการเชื่อมต่อกับฐานข้อมูล
Button(f1,bd=5,fg='black',bg='light blue',width=10,text='ยืนยัน',command=add).place(x=100,y=470)

def reset():
    entry_ชื่อ.delete(0,END)
    entry_เบอร์โทร.delete(0,END)
Button(f1,bd=5,fg='black',bg='light blue',width=10,text='ยกเลิก',command=reset).place(x=260,y=470)

# หน้าแสดงเมนูและสั่งซื้อสินค้า
global_image = None
def show_menu():
    root.withdraw()
    root1=tk.Toplevel()
    root1.title('แคชเชียร์')
    root1.geometry('1000x650+10+10')
    root1.resizable(FALSE,FALSE)
    root1.configure(background='white')
    img_path = "menu.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)

    # แสดงรูปภาพใน Label
    Label(root1, image=img, bg='white').place(x=0,y=0)
    root1.image = img  # เก็บอ้างอิงไว้เพื่อไม่ให้รูปถูกทำลายเมื่อฟังก์ชันจบ

    # เชื่อมต่อกับฐานข้อมูล SQLite
    conn = sqlite3.connect("ttsw.db")
    cursor = conn.cursor()

    # ดึงข้อมูลรูปภาพทั้งหมดจากตารางรูปภาพขนม
    cursor.execute("SELECT รูปภาพ FROM รูปภาพขนม")
    images_data = cursor.fetchall()

    x, y = 75, 200  # ตำแหน่งเริ่มต้นของรูปภาพแต่ละรูป
    image_count = 0  # นับจำนวนรูปภาพที่แสดง

    for image_data in images_data:
        # แปลงข้อมูลรูปภาพให้กลายเป็นรูปภาพใน Tkinter
        image_bytes = image_data[0]
        image_tk = ImageTk.PhotoImage(Image.open(BytesIO(image_bytes)))

        # สร้าง Label และแสดงรูปภาพในตำแหน่งที่แตกต่างกัน
        label = Label(root1, image=image_tk, bg='white')
        label.image = image_tk  # ต้องเก็บอ้างอิงเพิ่มเติมเพื่อป้องกันการทับรูป
        label.place(x=x, y=y)

        # นับจำนวนรูปภาพที่แสดงแล้ว
        image_count += 1

        # หากครบ 5 รูปภาพให้ขึ้นบรรทัดใหม่
        if image_count % 5 == 0:
            x = 75
            y += 100  # ห่างกัน 100 พิกเซลทางแนวแกน y
        else:
            x += 100  # ห่างกัน 100 พิกเซลทางแนวแกน x

    # ปิดการเชื่อมต่อกับฐานข้อมูล SQLite
    conn.close()

    # เชื่อมต่อกับฐานข้อมูล SQLite
    conn = sqlite3.connect("ttsw.db")
    cursor = conn.cursor()

    # ดึงข้อมูลรูปภาพทั้งหมดจากตารางรูปภาพเครื่องดืม
    cursor.execute("SELECT รูปภาพ FROM รูปภาพเครื่องดืม")
    images_drink = cursor.fetchall()

    x, y = 75, 500  # ตำแหน่งเริ่มต้นของรูปภาพแต่ละรูป
    drink_count = 0  # นับจำนวนรูปภาพที่แสดง

    for image_drink in images_drink:
        # แปลงข้อมูลรูปภาพให้กลายเป็นรูปภาพใน Tkinter
        drink_bytes = image_drink[0]
        drink_tk = ImageTk.PhotoImage(Image.open(BytesIO(drink_bytes)))

        # สร้าง Label และแสดงรูปภาพในตำแหน่งที่แตกต่างกัน
        label = Label(root1, image=drink_tk, bg='white')
        label.image = drink_tk  # ต้องเก็บอ้างอิงเพิ่มเติมเพื่อป้องกันการทับรูป
        label.place(x=x, y=y)

        # นับจำนวนรูปภาพที่แสดงแล้ว
        drink_count += 1

        # หากครบ 5 รูปภาพให้ขึ้นบรรทัดใหม่
        if drink_count % 5 == 0:
            x = 75
            y += 100  # ห่างกัน 100 พิกเซลทางแนวแกน y
        else:
            x += 100  # ห่างกัน 100 พิกเซลทางแนวแกน x

    # ปิดการเชื่อมต่อกับฐานข้อมูล SQLite
    conn.close()

    #คำนวณ
    def calculate_total():
        total = 0
        for i in range(len(products_and_prices)):
            quantity = int(quantity_entries[i].get())
            price = int(products_and_prices[i][1])  # แปลงราคาเป็น int
            total += quantity * price
        
        for i in range(len(drink_and_prices)):
            quantity = int(quantity_entries[len(products_and_prices) + i].get())
            price = int(drink_and_prices[i][1])  # แปลงราคาเครื่องดื่มเป็น int
            total += quantity * price

        total_label.config(text=f"ราคารวม : {total} บาท")
        return total

    def add_quantity(index):
        current_quantity = int(quantity_entries[index].get())
        quantity_entries[index].delete(0, tk.END)
        quantity_entries[index].insert(0, str(current_quantity + 1))
        calculate_total()

    def reduce_quantity(index):
        current_quantity = int(quantity_entries[index].get())
        if current_quantity > 0:
            quantity_entries[index].delete(0, tk.END)
            quantity_entries[index].insert(0, str(current_quantity - 1))
        calculate_total()

    def confirm_selection():
        selected_products = []
        selected_drinks = []
        
        for i in range(len(products_and_prices)):
            product_quantity = int(quantity_entries[i].get())
            if product_quantity > 0:
                selected_products.append((products_and_prices[i][0], product_quantity, products_and_prices[i][1]))

        for i in range(len(drink_and_prices)):
            drink_quantity = int(quantity_entries[len(products_and_prices) + i].get())
            if drink_quantity > 0:
                selected_drinks.append((drink_and_prices[i][0], drink_quantity, drink_and_prices[i][1]))

        if not selected_products and not selected_drinks:
            messagebox.showerror("ผิดพลาด", "โปรดเลือกรายการอย่างน้อยหนึ่งรายการ")
            return
            
        # ดึงชื่อผู้ใช้จากตาราง "ผู้ใช้"
        selected_phone = entry_login.get()
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()
        c.execute("SELECT ชื่อ FROM ผู้ใช้ WHERE เบอร์โทร=?", (selected_phone,))
        user_data = c.fetchone()
        conn.close()

        if not user_data:
            messagebox.showerror("ผิดพลาด", "ไม่พบข้อมูลผู้ใช้")
            return

        user_name = user_data[0]  # นี่คือชื่อผู้ใช้ที่ดึงมาจากฐานข้อมูล
        
        total = calculate_total()

        # เชื่อมต่อกับฐานข้อมูล SQLite
        conn = sqlite3.connect("ttsw.db")
        c = conn.cursor()

       # สร้างรายการสั่งซื้อในตาราง "คำสั่งซื้อ" สำหรับสินค้า
        for product, quantity, price in selected_products:
            order_date = datetime.now().strftime('%Y-%m-%d')
            order_time = datetime.now().strftime('%H:%M')
            c.execute("INSERT INTO คำสั่งซื้อ (วันที่, เวลา, ชื่อ, จำนวน, รายการ, ราคา) VALUES (?, ?, ?, ?, ?, ?)",
                    (order_date, order_time, user_name, quantity, product, price * quantity))

        # สร้างรายการสั่งซื้อในตาราง "คำสั่งซื้อ" สำหรับเครื่องดื่ม
        for drink, quantity, price in selected_drinks:
            order_date = datetime.now().strftime('%Y-%m-%d')
            order_time = datetime.now().strftime('%H:%M')
            c.execute("INSERT INTO คำสั่งซื้อ (วันที่, เวลา, ชื่อ, จำนวน, รายการ, ราคา) VALUES (?, ?, ?, ?, ?, ?)",
                    (order_date, order_time, user_name, quantity, drink, price * quantity))

        # บันทึกการเปลี่ยนแปลงในฐานข้อมูล
        conn.commit()
        conn.close()
    
        total = calculate_total()  # คำนวณราคารวมอีกครั้งหลังจากบันทึก

        # แสดงใบเสร็จ
        display_receipt(selected_products + selected_drinks, total)
        root1.withdraw()

    # สร้างเฟรมสำหรับแสดงชื่อสินค้าและปุ่มเพิ่มลดจำนวน
    topic_frame = tk.Frame(root1, width=350, height=50, bg='white')
    topic_frame.place(x=650,y=0)
    topic_label = tk.Label(topic_frame, text="คำนวณราคา", font='JasmineUPC 20 bold', bg='white')
    topic_label.place(x=130,y=0)

    # สร้างเฟรมสำหรับแสดงชื่อสินค้าและปุ่มเพิ่มลดจำนวน
    product_frame = tk.Frame(root1, width=350, height=550, bg='white')
    product_frame.place(x=650,y=35)

    # เชื่อมต่อกับฐานข้อมูล SQLite
    conn = sqlite3.connect("ttsw.db")
    cursor = conn.cursor()

    # ดึงข้อมูลชื่อสินค้าจากตาราง "ขนม"
    cursor.execute("SELECT ชื่อสินค้า, ราคา FROM ขนม")
    products_and_prices = cursor.fetchall()

    # ดึงข้อมูลชื่อสินค้าจากตาราง "เครื่องดืม"
    cursor.execute("SELECT ชื่อสินค้า, ราคา FROM เครื่องดืม")
    drink_and_prices = cursor.fetchall()

    conn.close()

    # สร้างแอเรย์เก็บ Entry widgets สำหรับจำนวน
    quantity_entries = []

    # สร้างแอเรย์เก็บ Label widgets สำหรับชื่อสินค้า
    product_labels = []

    for i, (product, price) in enumerate(products_and_prices):
        product_label = tk.Label(product_frame, text=product, font='JasmineUPC 15 bold', bg='white')
        product_label.grid(row=i, column=0, padx=30, pady=3)
        product_labels.append(product_label)

        quantity_entry = tk.Entry(product_frame, bg='white', width=5)
        quantity_entry.grid(row=i, column=2, padx=10, pady=3)
        quantity_entry.insert(0, '0')  # กำหนดจำนวนเริ่มต้นเป็น 0
        quantity_entries.append(quantity_entry)

        add_button = tk.Button(product_frame, text="+", command=lambda index=i: add_quantity(index))
        add_button.grid(row=i, column=3, padx=10, pady=3)

        reduce_button = tk.Button(product_frame, text="-", command=lambda index=i: reduce_quantity(index))
        reduce_button.grid(row=i, column=1, padx=10, pady=3)
    
    drink_start_row = len(products_and_prices)  # เริ่มต้นจากคอลัมน์ถัดไปหลังจากสินค้า

    for i, (drink, price) in enumerate(drink_and_prices):
        product_label = tk.Label(product_frame, text=drink, font='JasmineUPC 15 bold', bg='white')
        product_label.grid(row=drink_start_row + i, column=0, padx=30, pady=3)  # ใช้คอลัมน์ที่ 4 สำหรับเครื่องดื่ม
        product_labels.append(product_label)

        quantity_entry = tk.Entry(product_frame, bg='white', width=5)
        quantity_entry.grid(row=drink_start_row + i, column=2, padx=10, pady=3)  # ใช้คอลัมน์ที่ 5 สำหรับเครื่องดื่ม
        quantity_entry.insert(0, '0')  # กำหนดจำนวนเริ่มต้นเป็น 0
        quantity_entries.append(quantity_entry)

        add_drink = tk.Button(product_frame, text="+", command=lambda index=drink_start_row + i: add_quantity(index))
        add_drink.grid(row=drink_start_row + i, column=3, padx=10, pady=3)  # ใช้คอลัมน์ที่ 6 สำหรับเครื่องดื่ม

        reduce_drink = tk.Button(product_frame, text="-", command=lambda index=drink_start_row + i: reduce_quantity(index))
        reduce_drink.grid(row=drink_start_row + i, column=1, padx=10, pady=3)  # ใช้คอลัมน์ที่ 3 สำหรับเครื่องดื่ม

    total_label = tk.Label(product_frame, text="", font='JasmineUPC 15 bold', bg='white')
    total_label.grid(row=16, columnspan=7, padx=10, pady=8)  # กำหนดคอลัมน์ที่ 7 ให้ครอบรวมสินค้าและเครื่องดื่ม

    butto_frame = tk.Frame(root1, width=350, height=50, bg='white')
    butto_frame.place(x=650,y=600)

    calculate_button = tk.Button(butto_frame, text="ชำระเงิน ฿",font='JasmineUPC 20',bg='white',command=confirm_selection)
    calculate_button.place(x=100,y=0)

    def home():
        root1.withdraw()
        root.deiconify()
    Button(butto_frame,text='🛖',command=home,font='JasmineUPC 20',bg='white').place(x=235,y=0)
    conn.close()

# หน้าใบเสร็จ
def display_receipt(selected_items, total):
    confirmation_window = tk.Toplevel(root)
    confirmation_window.title("ใบเสร็จ")
    confirmation_window.geometry('400x750+1010+10')
    confirmation_window.resizable(FALSE,FALSE)
    confirmation_window.configure(background='white')
    # โหลดรูปภาพและแปลงเป็น ImageTk.PhotoImage
    img_path = "bill.png"
    img = Image.open(img_path)
    img = ImageTk.PhotoImage(img)
    # แสดงรูปภาพใน Label
    Label(confirmation_window, image=img, bg='white').place(x=0,y=0)

    confirmation_window.image = img  # เก็บอ้างอิงไว้เพื่อไม่ให้รูปถูกทำลายเมื่อฟังก์ชันจบ
    Label(confirmation_window,text='ใบเสร็จรับเงิน',fg='black',font='JasmineUPC 15 bold',bg='white').place(x=150,y=100)
    # แสดงวันที่และเวลาปัจจุบัน
    current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M')
    Label(confirmation_window, text=f'{current_datetime}', fg='black', font='JasmineUPC 10', bg='white').place(x=300, y=100)

    fff1=Frame(confirmation_window, bg='white',highlightbackground='white',highlightthickness=0,width=400,height=200)
    fff1.place(x=0,y=130)
    Label(fff1, text="จำนวน",font='JasmineUPC 15',bg='white').place(x=10,y=0)
    Label(fff1, text="รายการ",font='JasmineUPC 15',bg='white').place(x=130,y=0)
    Label(fff1, text="ราคา",font='JasmineUPC 15',bg='white').place(x=320,y=0)

    fff2=Frame(confirmation_window, bg='white',highlightbackground='white',highlightthickness=0,width=400,height=450)
    fff2.place(x=0,y=160)
    for i, (product, quantity, price) in enumerate(selected_items):

        productlabel = tk.Label(fff2, text=f"{product}",font='JasmineUPC 15',bg='white')
        productlabel.grid(row=i, column=1, padx=40, pady=2)

        quantitylabel = tk.Label(fff2, text=f"{quantity}",font='JasmineUPC 15',bg='white')
        quantitylabel.grid(row=i, column=0, padx=20, pady=2)

        totallabel = tk.Label(fff2, text=f"{price * quantity} -.",font='JasmineUPC 15',bg='white')
        totallabel.grid(row=i, column=4, padx=50, pady=2)

    total_label = tk.Label(fff2, text=f"ราคารวม: {total} บาท", bg='white')
    total_label.grid(row=len(selected_items) + 1, column=4, padx=10, pady=3)

    conn = sqlite3.connect("ttsw.db")
    c = conn.cursor()

    # ดึงชื่อผู้ใช้จากฐานข้อมูล
    selected_phone = entry_login.get()
    c.execute("SELECT จำนวนเข้าใช้บริการ FROM ผู้ใช้ WHERE เบอร์โทร=?", (selected_phone,))
    user_data = c.fetchone()
    conn.close()

    user_used = user_data[0]

    # ตรวจสอบจำนวนการเข้าใช้งาน
    if user_used == '1':
        Label(fff2, text="1", font='JasmineUPC 15', bg='white').grid(row=len(selected_items), column=0, padx=10, pady=2)
        Label(fff2, text="*เมนูพิเศษ* บิงซูผลไม้", font='JasmineUPC 15', bg='white').grid(row=len(selected_items), column=1, padx=10, pady=2)
        Label(fff2, text="ฟรี", font='JasmineUPC 15', bg='white').grid(row=len(selected_items), column=4, padx=10, pady=2)

    def home():
        root.deiconify()
        confirmation_window.withdraw()
    ok_button = tk.Button(confirmation_window, text="เรียบร้อย", command=home, bg='white')
    ok_button.place(x=255,y=720)

conn.commit()
root.mainloop()
conn.close()